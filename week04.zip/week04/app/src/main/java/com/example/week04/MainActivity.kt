

package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.fragment.app.FragmentManager
import com.example.week04.R

class lookiesWeek4 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button1 : Button = findViewById(R.id.fracc1)
        val button2 : Button = findViewById(R.id.fracc2)
        val button3 : Button = findViewById(R.id.fracc3)
        val button4 : Button = findViewById(R.id.fracc4)

        button1.setOnClickListener {
            val fragment:week4Fragment1 = week4Fragment1()
            val fragmentManager :FragmentManager = supportFragmentManager
            val fragmentTransaction = fragmentManager.beginTransaction()
            fragmentTransaction.replace(R.id.container, fragment)
            fragmentTransaction.commit()
        }


        button2.setOnClickListener {
            val fragment:week4Fragment2 = week4Fragment2()
            val fragmentManager :FragmentManager = supportFragmentManager
            val fragmentTransaction = fragmentManager.beginTransaction()
            fragmentTransaction.replace(R.id.container, fragment)
            fragmentTransaction.commit()
        }


        button3.setOnClickListener {
            val fragment:week4Fragment3 = week4Fragment3()
            val fragmentManager :FragmentManager = supportFragmentManager
            val fragmentTransaction = fragmentManager.beginTransaction()
            fragmentTransaction.replace(R.id.container, fragment)
            fragmentTransaction.commit()
        }


        button4.setOnClickListener {
            val fragment:week4Fragment4 = week4Fragment4()
            val fragmentManager :FragmentManager = supportFragmentManager
            val fragmentTransaction = fragmentManager.beginTransaction()
            fragmentTransaction.replace(R.id.container, fragment)
            fragmentTransaction.commit()
        }
    }
}