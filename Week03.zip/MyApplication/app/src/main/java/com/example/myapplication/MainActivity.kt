package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        A.setOnClickListener {
            val intent1 = Intent(this, Intent1::class.java)
            startActivity(intent1)
        }
        B.setOnClickListener {
            val intent2 = Intent(this, Intent2::class.java)
            startActivity(intent2)
        }
        C.setOnClickListener {
            val intent3 = Intent(this, Intent3::class.java)
            startActivity(intent3)
        }


    }
}